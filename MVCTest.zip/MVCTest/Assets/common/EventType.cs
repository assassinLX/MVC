﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EventType:Object {
    //定义各种事件类型
    public const string GAME_START = "game.start";
    public const string GAME_RUNNING = "game.running";
    public const string CUBE_CLICK = "cube.click";
    public const string GAME_OVER = "game.over";
    public const string ENEMY_KILLING = "enemy.killing";
}
