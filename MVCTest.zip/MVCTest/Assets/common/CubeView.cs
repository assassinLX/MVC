﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CubeView : View {

    private void OnMouseDown()
    {
        Debug.Log("Clicked");
        App.Notify(EventType.CUBE_CLICK, this);
    }

    // Update is called once per frame
    void Update () {
		
	}
}