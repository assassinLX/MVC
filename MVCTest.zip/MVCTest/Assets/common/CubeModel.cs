﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CubeModel : Model {
    public int score;
    public int winCondition = 5;
    public void AddScore()
    {
        score++;
        if(score >= winCondition)
        {
            App.Notify(EventType.GAME_OVER, this);
        }
    }

}
