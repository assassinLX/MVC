﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CubeApplication : MonoBehaviour {
    
    public void ViewNotify(string event_name, Object p_target, params object[] p_data)
    {
        View[] viewList = GetAllViews();
        foreach (View v in viewList)
        {
            v.OnNotification(event_name, p_target, p_data);
        }
    }
    public void ControllerNotify(string event_name, Object p_target, params object[] p_data)
    {
        Controller[] controllerList = GetAllControllers();
        foreach (Controller c in controllerList)
        {
            c.OnNotification(event_name, p_target, p_data);
        }
    }
    public void Notify(string event_name, Object p_target, params object[] p_data)
    {
        ControllerNotify(event_name, p_target, p_data);
        ViewNotify(event_name, p_target, p_data);
    }

    private View[] GetAllViews()
    {
        return GameObject.FindObjectsOfType<View>();
    }
    private Controller[] GetAllControllers()
    {
        return GameObject.FindObjectsOfType<Controller>();
    }
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
