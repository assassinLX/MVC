﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CubeController : Controller {

    public override void OnNotification(string event_name,
        Object p_target, params object[] p_data)
    {
        switch (event_name)
        {
            case EventType.GAME_START:
                break;
            case EventType.CUBE_CLICK:
                               
                break;
            case EventType.GAME_OVER:
                Debug.Log("Game Win!");
                break;
        }
    }
}
