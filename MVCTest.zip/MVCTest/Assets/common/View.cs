﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class View : Element {

	public virtual void OnNotification(string event_name,
        Object p_target, params object[] p_data)
    { }
}
