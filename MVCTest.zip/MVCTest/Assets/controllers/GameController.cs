﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameController : Controller {
    private void Start()
    {
        Debug.Log("Game Start");
        App.Notify(EventType.GAME_START, this);
    }
}
