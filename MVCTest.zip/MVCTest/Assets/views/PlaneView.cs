﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlaneView : View {
    public int speed = 5;
    private bool isRunning = false;
	// Use this for initialization
	void Start () {
		
	}

    private void OnTriggerEnter(Collider other)
    {
        App.Notify(EventType.GAME_OVER,this);
    }

    public override void OnNotification(string event_name, 
        Object p_target, params object[] p_data)
    {
        switch (event_name)
        {
            case EventType.GAME_START:
                isRunning = false;
                break;
            case EventType.GAME_RUNNING:
                isRunning = true;
                break;
        }
    }

    // Update is called once per frame
    void Update () {
        if (isRunning)
        {
            float deltaX = Input.GetAxis("Horizontal");
            float deltaXTime = deltaX * speed * Time.deltaTime;
            this.transform.Translate(new Vector3(deltaXTime, 0, 0));
        }
	}
}
