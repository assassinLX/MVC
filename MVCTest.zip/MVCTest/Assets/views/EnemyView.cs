﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyView : View {

    public override void OnNotification(string event_name, 
        Object p_target, params object[] p_data)
    {
        switch (event_name)
        {
            case EventType.GAME_OVER:
                Destroy(this.gameObject);
                break;
        }
    }
    // Update is called once per frame
    void Update () {
		
	}
}
