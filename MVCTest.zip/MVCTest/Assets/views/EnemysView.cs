﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemysView : View {
    public GameObject enemyPrefab;
    private bool isRunning = false;
    public float timerStep = 2;
    private float timer;
    public override void OnNotification(string event_name,
        Object p_target, params object[] p_data)
    {
        switch (event_name)
        {
            case EventType.GAME_RUNNING:
                timer = timerStep;
                CreateEnemys(3);
                isRunning = true;
                break;
            case EventType.GAME_OVER:
                isRunning = false;
                break;
        }
    }

    private void CreateEnemys(int count)
    {
        for(int i = 0; i < count; i++)
        {
            int x = Random.Range(0, 4) - 2;
            Instantiate(enemyPrefab, new Vector3(x, 0, -1.6f),
                Quaternion.identity);
        }
    }

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        if (isRunning)
        {
            if (Time.time > timer)
            {
                //创建敌人
                CreateEnemys(3);
                timer = timerStep + Time.time;
            }
        }
	}
}
