﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIView : View {
    public GameObject Plane;
    public Button btn;
	// Use this for initialization
	void Awake () {
        UIClose();
        btn.onClick.AddListener(OnClick); 
	}
    void OnClick()
    {
        App.Notify(EventType.GAME_RUNNING, this);
    }
    public override void OnNotification(string event_name, 
        Object p_target, params object[] p_data)
    {
        switch (event_name)
        {
            case EventType.GAME_START:
                Debug.Log("UIView Start");
                UIShow();
                break;
            case EventType.GAME_RUNNING:
                UIClose();
                break;
            case EventType.GAME_OVER:
                UIShow();
                break;
        }
    }
    void UIClose()
    {
        Plane.SetActive(false);
    }
    void UIShow()
    {
        Plane.SetActive(true);
    }
	
	// Update is called once per frame
	void Update () {
		
	}
}
